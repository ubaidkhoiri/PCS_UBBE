package com.ubbe.app.ui.auth

import androidx.lifecycle.ViewModel
import com.ubbe.app.data.repository.AuthRepository

class AuthViewModel(repo: AuthRepository): ViewModel() {

}
package com.ubbe.app.data.repository

class AuthRepository {
}